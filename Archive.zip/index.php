<html>
<head>
    <title>Leaflet JS with OpenWeatherMap and AmCharts</title>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6_OKikBph5KZMEJR6g1UJ1r1slgMfKLM" async
            defer></script>
    <link rel="stylesheet" href="css/app.css">
</head>
<body>
<div id="mapid"></div>
<div class="footer">Get source code here: <a href="https://github.com/hazelnuts23/leaflet-charts-weather" target="_blank">GitHub</a></div>
<script type="text/javascript" src="js/app.js"></script>
</body>
</html>